#ifndef DISPLAY_H
#define DISPLAY_H

#include "main.h"
#include "stdint.h"
#include "stdbool.h"

// 声明外部 SPI 句柄
extern SPI_HandleTypeDef hspi1;

// 函数声明

/**
 * @brief 重置 LCD 模块
 */
void LCDReset(void);

/**
 * @brief 向 LCD 发送命令
 * 
 * @param command 要发送的命令字节
 */
void LCDWriteCommand(uint8_t command);

/**
 * @brief 向 LCD 发送数据
 * 
 * @param data 要发送的数据字节
 */
void LCDWriteData(uint8_t data);

/**
 * @brief 初始化 LCD 模块
 */
void LCDInit(void);

/**
 * @brief 设置 LCD 显示窗口
 * 
 * @param Xstart 窗口起始 X 坐标
 * @param Ystart 窗口起始 Y 坐标
 * @param Xend 窗口结束 X 坐标
 * @param Yend 窗口结束 Y 坐标
 */
void LCDSetWindow(uint16_t Xstart, uint16_t Ystart, uint16_t Xend, uint16_t Yend);

/**
 * @brief 设置 LCD 光标位置
 * 
 * @param X 光标的 X 坐标
 * @param Y 光标的 Y 坐标
 */
void LCDSetCursor(uint16_t X, uint16_t Y);

/**
 * @brief 清除整个 LCD 屏幕并填充指定颜色
 * 
 * @param Color 要填充的颜色
 */
void LCDClear(uint16_t Color);

/**
 * @brief 清除指定窗口区域并填充指定颜色
 * 
 * @param Xstart 窗口起始 X 坐标
 * @param Ystart 窗口起始 Y 坐标
 * @param Xend 窗口结束 X 坐标
 * @param Yend 窗口结束 Y 坐标
 * @param color 要填充的颜色
 */
void LCDClearWindow(uint16_t Xstart, uint16_t Ystart, uint16_t Xend, uint16_t Yend, uint16_t color);

/**
 * @brief 在指定位置绘制单个像素
 * 
 * @param x 像素的 X 坐标
 * @param y 像素的 Y 坐标
 * @param Color 像素的颜色
 */
void LCDDrawPixel(uint16_t x, uint16_t y, uint16_t Color);

/**
 * @brief 显示整张图像
 * 
 * @param image 图像数据指针
 * @param width 图像宽度
 * @param height 图像高度
 */
void LCDDisplayImage(const uint16_t *image, uint16_t width, uint16_t height);

/**
 * @brief 显示指定区域的图像
 * 
 * @param image 区域图像数据指针
 * @param startX 区域起始 X 坐标
 * @param startY 区域起始 Y 坐标
 * @param width 区域宽度
 * @param height 区域高度
 */
void LCDDisplayRegion(const uint16_t *image, uint16_t startX, uint16_t startY, uint16_t width, uint16_t height);

#endif /* DISPLAY_H */
