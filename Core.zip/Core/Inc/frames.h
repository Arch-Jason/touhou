#ifndef FRAMES_H
#define FRAMES_H

#include "stdint.h"

extern const uint16_t framebuffer[2][240 * 320];

#endif
