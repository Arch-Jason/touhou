#ifndef PLAYER_H
#define PLAYER_H

#include "stdint.h"
#include "main.h"

void Tone(uint32_t Frequency, uint32_t Duration);
void noTone();

#endif