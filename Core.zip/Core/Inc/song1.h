#ifndef SONG1_H
#define SONG1_H

void playSong1();

#endif