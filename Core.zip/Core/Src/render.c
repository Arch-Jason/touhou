#include "render.h"
#include "stdlib.h"
#include "frames.h"
#include "display.h"
#include "stdio.h"
#include "main.h"
#include "FreeRTOS.h"
#include "semphr.h"

extern struct enemyBullet bullets[500];
extern uint16_t playerPosition[2];
extern SemaphoreHandle_t renderFlag;

extern UART_HandleTypeDef huart2;

#define BLOCK_HEIGHT 5 // 分块高度，调整以适配内存需求
#define LCD_WIDTH 240
#define LCD_HEIGHT 320

void drawSquareBlock(uint16_t *block, uint16_t blockStartX, uint16_t blockStartY, uint16_t x, uint16_t y, uint16_t sideLength, uint16_t color) {
    int halfSide = sideLength / 2;
    for (int i = -halfSide; i <= halfSide; i++) {
        for (int j = -halfSide; j <= halfSide; j++) {
            int drawX = x + j - blockStartX;
            int drawY = y + i - blockStartY;
            if (drawX >= 0 && drawX < LCD_WIDTH && drawY >= 0 && drawY < BLOCK_HEIGHT) {
                block[drawY * LCD_WIDTH + drawX] = color;
            }
        }
    }
}

void render(void *argument) {
    // 分块缓冲区
    uint16_t *blockBuffer = malloc(LCD_WIDTH * BLOCK_HEIGHT * sizeof(uint16_t));
    if (!blockBuffer) {
        HAL_UART_Transmit(&huart2, (uint8_t *)"Memory allocation failed!\r\n", 27, HAL_MAX_DELAY);
        return;
    }

    while(1) {
        if (xSemaphoreTake(renderFlag, (TickType_t)10) == pdTRUE) {
            HAL_UART_Transmit(&huart2, (uint8_t *)"render start!\r\n", 10, HAL_MAX_DELAY);
            // HAL_UART_Transmit(&huart2, (uint8_t *)"1 complete\r\n", 14, HAL_MAX_DELAY);

            // 渲染循环
            if (renderFlag) {
                for (uint16_t blockY = 0; blockY < LCD_HEIGHT; blockY += BLOCK_HEIGHT) {
                    // 初始化当前分块为白色
                    for (uint16_t i = 0; i < BLOCK_HEIGHT * LCD_WIDTH; i++) {
                        blockBuffer[i] = 0xFFFF; // 白色背景
                    }

                    // 绘制子弹到当前分块
                    for (uint16_t i = 0; i < 500; i++) {
                        if (bullets[i].type == 1 &&
                            bullets[i].y >= blockY &&
                            bullets[i].y < blockY + BLOCK_HEIGHT) {
                            drawSquareBlock(blockBuffer, 0, blockY, bullets[i].x, bullets[i].y, 15, 0x001F); // 蓝色
                        }
                    }

                    // 绘制玩家到当前分块
                    if (playerPosition[1] >= blockY && playerPosition[1] < blockY + BLOCK_HEIGHT) {
                        drawSquareBlock(blockBuffer, 0, blockY, playerPosition[0], playerPosition[1], 15, 0xF800); // 红色
                    }

                    // 将分块发送到 LCD
                    LCDDisplayRegion(blockBuffer, 0, blockY, LCD_WIDTH, BLOCK_HEIGHT);
                }
            }
            HAL_UART_Transmit(&huart2, (uint8_t *)"2 complete\r\n", 14, HAL_MAX_DELAY);

            xSemaphoreGive(renderFlag);        
        }
    }
}
