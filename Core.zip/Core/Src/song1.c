#include "player.h"
#include "song1.h"

void playSong1() {
    while(1) {
        Tone(493, 206);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(493, 206);
        Tone(587, 206);
        Tone(659, 620);
        Tone(587, 103);
        Tone(659, 103);
        Tone(587, 206);
        Tone(493, 206);
        Tone(440, 206);
        Tone(587, 206);
        Tone(493, 1241);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(493, 206);
        Tone(587, 206);
        Tone(659, 620);
        Tone(587, 103);
        Tone(659, 103);
        Tone(783, 206);
        Tone(739, 206);
        Tone(659, 206);
        Tone(587, 206);
        Tone(659, 1034);
        Tone(587, 103);
        Tone(659, 103);
        Tone(587, 206);
        Tone(493, 206);
        Tone(440, 1034);
        Tone(587, 103);
        Tone(659, 103);
        Tone(587, 206);
        Tone(440, 206);
        Tone(391, 1241);
        Tone(329, 206);
        Tone(369, 206);
        Tone(391, 620);
        Tone(440, 206);
        Tone(369, 620);
        Tone(329, 206);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(329, 1654);
        Tone(440, 1654);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(440, 827);
        Tone(391, 827);
        Tone(440, 1241);
        Tone(523, 413);
        Tone(493, 620);
        Tone(440, 620);
        Tone(391, 413);
        Tone(440, 827);
        Tone(587, 827);
        Tone(523, 413);
        Tone(493, 413);
        Tone(440, 413);
        Tone(493, 413);
        Tone(523, 620);
        Tone(587, 620);
        Tone(659, 827);
        Tone(587, 413);
        Tone(523, 413);
        Tone(493, 413);
        Tone(440, 1654);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(440, 827);
        Tone(391, 827);
        Tone(440, 1241);
        Tone(523, 413);
        Tone(493, 620);
        Tone(440, 620);
        Tone(391, 413);
        Tone(440, 413);
        Tone(329, 206);
        Tone(391, 413);
        Tone(440, 206);
        Tone(329, 413);
        Tone(293, 827);
        Tone(329, 413);
        Tone(391, 413);
        Tone(440, 3309);
        Tone(329, 827);
        Tone(493, 309);
        Tone(440, 309);
        Tone(391, 206);
        Tone(369, 1034);
        Tone(293, 206);
        Tone(246, 413);
        Tone(329, 2482);
        Tone(369, 827);
        Tone(391, 827);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(391, 309);
        Tone(440, 309);
        Tone(493, 206);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(493, 827);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(493, 309);
        Tone(554, 309);
        Tone(587, 206);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(587, 413);
        Tone(554, 413);
        Tone(493, 413);
        Tone(587, 413);
        Tone(659, 620);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(659, 206);
        Tone(622, 827);
        Tone(659, 309);
        Tone(493, 309);
        Tone(440, 206);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(440, 309);
        Tone(391, 309);
        Tone(440, 206);
        Tone(329, 827);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(329, 309);
        Tone(369, 309);
        Tone(391, 206);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(391, 413);
        Tone(369, 413);
        Tone(329, 413);
        Tone(293, 413);
        Tone(329, 827);
        Tone(369, 827);
        Tone(659, 309);
        Tone(493, 309);
        Tone(440, 206);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(440, 309);
        Tone(391, 309);
        Tone(440, 206);
        Tone(329, 827);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(329, 309);
        Tone(369, 309);
        Tone(391, 206);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(391, 309);
        Tone(440, 309);
        Tone(493, 206);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(493, 309);
        Tone(554, 309);
        Tone(587, 206);
        Tone(622, 413);
        Tone(659, 413);
        Tone(739, 206);
        Tone(493, 206);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(493, 206);
        Tone(587, 206);
        Tone(659, 620);
        Tone(587, 103);
        Tone(659, 103);
        Tone(587, 206);
        Tone(493, 206);
        Tone(440, 206);
        Tone(587, 206);
        Tone(493, 1241);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(493, 206);
        Tone(587, 206);
        Tone(659, 620);
        Tone(587, 103);
        Tone(659, 103);
        Tone(783, 206);
        Tone(739, 206);
        Tone(659, 206);
        Tone(587, 206);
        Tone(659, 1034);
        Tone(587, 103);
        Tone(659, 103);
        Tone(587, 206);
        Tone(493, 206);
        Tone(440, 1034);
        Tone(587, 103);
        Tone(659, 103);
        Tone(587, 206);
        Tone(440, 206);
        Tone(391, 1241);
        Tone(329, 206);
        Tone(369, 206);
        Tone(391, 1034);
        Tone(440, 206);
        Tone(493, 206);
        Tone(523, 206);
        Tone(493, 1034);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(493, 206);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(493, 206);
        Tone(587, 206);
        Tone(659, 620);
        Tone(587, 103);
        Tone(659, 103);
        Tone(587, 206);
        Tone(493, 206);
        Tone(440, 206);
        Tone(587, 206);
        Tone(493, 1241);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(493, 206);
        Tone(587, 206);
        Tone(659, 620);
        Tone(587, 103);
        Tone(659, 103);
        Tone(783, 206);
        Tone(739, 206);
        Tone(659, 206);
        Tone(587, 206);
        Tone(659, 1034);
        Tone(587, 103);
        Tone(659, 103);
        Tone(587, 206);
        Tone(493, 206);
        Tone(440, 1034);
        Tone(587, 103);
        Tone(659, 103);
        Tone(587, 206);
        Tone(440, 206);
        Tone(391, 1241);
        Tone(329, 206);
        Tone(369, 206);
        Tone(391, 620);
        Tone(440, 206);
        Tone(369, 620);
        Tone(329, 206);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(329, 1241);
        noTone(); // 10ms pause between same notes
        osDelay(10);
        Tone(329, 206);
        Tone(369, 206);
        Tone(391, 620);
        Tone(440, 206);
        Tone(369, 309);
        Tone(440, 309);
        Tone(587, 206);
        Tone(659, 1654);
    }
}