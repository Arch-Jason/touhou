#include "display.h"
#include "stdint.h"
#include "stdbool.h"

/* 定义 LCD 分辨率和 SPI 最大传输大小 */
#define LCD_WIDTH 240
#define LCD_HEIGHT 320
#define SPI_MAX_TRANSFER_SIZE 256

/**
 * @brief 重置 LCD 模块
 */
void LCDReset() {
    HAL_GPIO_WritePin(CS_GPIO_Port, CS_Pin, GPIO_PIN_SET);
    HAL_Delay(200);
    HAL_GPIO_WritePin(CS_GPIO_Port, CS_Pin, GPIO_PIN_RESET);
    HAL_Delay(200);
    HAL_GPIO_WritePin(RST_GPIO_Port, RST_Pin, GPIO_PIN_RESET);
    HAL_Delay(200);
    HAL_GPIO_WritePin(RST_GPIO_Port, RST_Pin, GPIO_PIN_SET);
    HAL_Delay(200);
}

/**
 * @brief 向 LCD 发送命令
 * 
 * @param command 要发送的命令字节
 */
void LCDWriteCommand(uint8_t command) {
    // 等待 SPI 空闲
    while (HAL_SPI_GetState(&hspi1) == HAL_SPI_STATE_BUSY_TX) {}
    
    HAL_GPIO_WritePin(CS_GPIO_Port, CS_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(DC_GPIO_Port, DC_Pin, GPIO_PIN_RESET);
    HAL_SPI_Transmit(&hspi1, &command, 1, HAL_MAX_DELAY);
    HAL_GPIO_WritePin(CS_GPIO_Port, CS_Pin, GPIO_PIN_SET);
}

/**
 * @brief 向 LCD 发送数据
 * 
 * @param data 要发送的数据字节
 */
void LCDWriteData(uint8_t data) {
    // 等待 SPI 空闲
    while (HAL_SPI_GetState(&hspi1) == HAL_SPI_STATE_BUSY_TX) {}
    
    HAL_GPIO_WritePin(CS_GPIO_Port, CS_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(DC_GPIO_Port, DC_Pin, GPIO_PIN_SET);
    HAL_SPI_Transmit(&hspi1, &data, 1, HAL_MAX_DELAY);
    HAL_GPIO_WritePin(CS_GPIO_Port, CS_Pin, GPIO_PIN_SET);
}

/**
 * @brief 初始化 LCD 模块
 */
void LCDInit() {
    HAL_GPIO_WritePin(BL_GPIO_Port, BL_Pin, GPIO_PIN_SET); // 打开背光
    LCDReset();

    // 配置 LCD 的初始化命令序列
    LCDWriteCommand(0x36);
    LCDWriteData(0x00);

    LCDWriteCommand(0x3A);
    LCDWriteData(0x05);

    LCDWriteCommand(0x21);

    LCDWriteCommand(0x2A);
    LCDWriteData(0x00);
    LCDWriteData(0x00);
    LCDWriteData(0x01);
    LCDWriteData(0x3F);

    LCDWriteCommand(0x2B);
    LCDWriteData(0x00);
    LCDWriteData(0x00);
    LCDWriteData(0x00);
    LCDWriteData(0xEF);

    LCDWriteCommand(0xB2);
    LCDWriteData(0x0C);
    LCDWriteData(0x0C);
    LCDWriteData(0x00);
    LCDWriteData(0x33);
    LCDWriteData(0x33);

    LCDWriteCommand(0xB7);
    LCDWriteData(0x35);

    LCDWriteCommand(0xBB);
    LCDWriteData(0x1F);

    LCDWriteCommand(0xC0);
    LCDWriteData(0x2C);

    LCDWriteCommand(0xC2);
    LCDWriteData(0x01);

    LCDWriteCommand(0xC3);
    LCDWriteData(0x12);

    LCDWriteCommand(0xC4);
    LCDWriteData(0x20);

    LCDWriteCommand(0xC6);
    LCDWriteData(0x0F);

    LCDWriteCommand(0xD0);
    LCDWriteData(0xA4);
    LCDWriteData(0xA1);

    LCDWriteCommand(0xE0);
    LCDWriteData(0xD0);
    LCDWriteData(0x08);
    LCDWriteData(0x11);
    LCDWriteData(0x08);
    LCDWriteData(0x0C);
    LCDWriteData(0x15);
    LCDWriteData(0x39);
    LCDWriteData(0x33);
    LCDWriteData(0x50);
    LCDWriteData(0x36);
    LCDWriteData(0x13);
    LCDWriteData(0x14);
    LCDWriteData(0x29);
    LCDWriteData(0x2D);

    LCDWriteCommand(0xE1);
    LCDWriteData(0xD0);
    LCDWriteData(0x08);
    LCDWriteData(0x10);
    LCDWriteData(0x08);
    LCDWriteData(0x06);
    LCDWriteData(0x06);
    LCDWriteData(0x39);
    LCDWriteData(0x44);
    LCDWriteData(0x51);
    LCDWriteData(0x0B);
    LCDWriteData(0x16);
    LCDWriteData(0x14);
    LCDWriteData(0x2F);
    LCDWriteData(0x31);
    LCDWriteCommand(0x21);

    LCDWriteCommand(0x11);
    HAL_Delay(120);

    LCDWriteCommand(0x29);
    HAL_Delay(10);
}

/**
 * @brief 设置显示窗口
 * 
 * @param Xstart 窗口起始 X 坐标
 * @param Ystart 窗口起始 Y 坐标
 * @param Xend 窗口结束 X 坐标
 * @param Yend 窗口结束 Y 坐标
 */
void LCDSetWindow(uint16_t Xstart, uint16_t Ystart, uint16_t Xend, uint16_t Yend) {
    LCDWriteCommand(0x2A);
    LCDWriteData((Xstart >> 8) & 0xFF);
    LCDWriteData(Xstart & 0xFF);
    LCDWriteData(((Xend - 1) >> 8) & 0xFF);
    LCDWriteData((Xend - 1) & 0xFF);

    LCDWriteCommand(0x2B);
    LCDWriteData((Ystart >> 8) & 0xFF);
    LCDWriteData(Ystart & 0xFF);
    LCDWriteData(((Yend - 1) >> 8) & 0xFF);
    LCDWriteData((Yend - 1) & 0xFF);

    LCDWriteCommand(0x2C);
}

/**
 * @brief 设置光标位置
 * 
 * @param X 光标的 X 坐标
 * @param Y 光标的 Y 坐标
 */
void LCDSetCursor(uint16_t X, uint16_t Y) {
    LCDSetWindow(X, Y, X + 1, Y + 1);
}

/**
 * @brief 清除整个屏幕并填充指定颜色
 * 
 * @param Color 要填充的颜色
 */
void LCDClear(uint16_t Color) {
    LCDClearWindow(0, 0, LCD_WIDTH, LCD_HEIGHT, Color);
}

/**
 * @brief 清除指定窗口区域并填充指定颜色
 * 
 * @param Xstart 窗口起始 X 坐标
 * @param Ystart 窗口起始 Y 坐标
 * @param Xend 窗口结束 X 坐标
 * @param Yend 窗口结束 Y 坐标
 * @param color 要填充的颜色
 */
void LCDClearWindow(uint16_t Xstart, uint16_t Ystart, uint16_t Xend, uint16_t Yend, uint16_t color) {          
    uint8_t colorBuffer[SPI_MAX_TRANSFER_SIZE];
    uint32_t totalPixels = (Xend - Xstart) * (Yend - Ystart);
    uint32_t totalBytes = totalPixels * 2; // 每个像素2字节
    uint32_t bufferSize = sizeof(colorBuffer);
    uint32_t pixelsPerTransfer = bufferSize / 2;

    // 填充颜色缓冲区
    for (uint32_t i = 0; i < pixelsPerTransfer; i++) {
        colorBuffer[2 * i] = (color >> 8) & 0xFF;
        colorBuffer[2 * i + 1] = color & 0xFF;
    }

    LCDSetWindow(Xstart, Ystart, Xend, Yend);
    HAL_GPIO_WritePin(DC_GPIO_Port, DC_Pin, GPIO_PIN_SET);

    for (uint32_t i = 0; i < totalPixels; i += pixelsPerTransfer) {
        uint32_t remainingPixels = totalPixels - i;
        uint32_t currentPixels = (remainingPixels > pixelsPerTransfer) ? pixelsPerTransfer : remainingPixels;
        uint32_t dataSize = currentPixels * 2;

        // 发送数据
        HAL_SPI_Transmit_DMA(&hspi1, colorBuffer, dataSize);
        // 等待 DMA 传输完成
        while (HAL_SPI_GetState(&hspi1) != HAL_SPI_STATE_READY) {}
    }
}

/**
 * @brief 在指定位置绘制单个像素
 * 
 * @param x 像素的 X 坐标
 * @param y 像素的 Y 坐标
 * @param Color 像素的颜色
 */
void LCDDrawPixel(uint16_t x, uint16_t y, uint16_t Color) {
    LCDSetCursor(x, y);
    uint8_t data[2];
    data[0] = (Color >> 8) & 0xFF;
    data[1] = Color & 0xFF;
    HAL_SPI_Transmit(&hspi1, data, 2, HAL_MAX_DELAY);
}

/**
 * @brief 显示整张图像
 * 
 * @param image 图像数据指针
 * @param width 图像宽度
 * @param height 图像高度
 */
void LCDDisplayImage(const uint16_t *image, uint16_t width, uint16_t height) {
    uint8_t buffer[SPI_MAX_TRANSFER_SIZE];
    uint32_t totalPixels = width * height;
    uint32_t bufferSize = sizeof(buffer);
    uint32_t pixelsPerTransfer = bufferSize / 2;

    LCDSetWindow(0, 0, width, height);
    HAL_GPIO_WritePin(DC_GPIO_Port, DC_Pin, GPIO_PIN_SET);

    for (uint32_t i = 0; i < totalPixels; i += pixelsPerTransfer) {
        uint32_t remainingPixels = totalPixels - i;
        uint32_t currentPixels = (remainingPixels > pixelsPerTransfer) ? pixelsPerTransfer : remainingPixels;
        uint32_t dataSize = currentPixels * 2;

        // 填充缓冲区
        for (uint32_t j = 0; j < currentPixels; j++) {
            buffer[2 * j] = (image[i + j] >> 8) & 0xFF;
            buffer[2 * j + 1] = image[i + j] & 0xFF;
        }

        // 发送数据
        HAL_SPI_Transmit_DMA(&hspi1, buffer, dataSize);
        // 等待 DMA 传输完成
        while (HAL_SPI_GetState(&hspi1) != HAL_SPI_STATE_READY) {}
    }
}

/**
 * @brief 显示指定区域的图像
 * 
 * @param image 区域图像数据指针
 * @param startX 区域起始 X 坐标
 * @param startY 区域起始 Y 坐标
 * @param width 区域宽度
 * @param height 区域高度
 */
void LCDDisplayRegion(const uint16_t *image, uint16_t startX, uint16_t startY, uint16_t width, uint16_t height) {
    uint8_t buffer[SPI_MAX_TRANSFER_SIZE];
    uint32_t totalPixels = width * height;
    uint32_t pixelsPerTransfer = SPI_MAX_TRANSFER_SIZE / 2;

    LCDSetWindow(startX, startY, startX + width, startY + height);
    HAL_GPIO_WritePin(DC_GPIO_Port, DC_Pin, GPIO_PIN_SET);

    for (uint32_t i = 0; i < totalPixels; i += pixelsPerTransfer) {
        uint32_t remainingPixels = totalPixels - i;
        uint32_t currentPixels = (remainingPixels > pixelsPerTransfer) ? pixelsPerTransfer : remainingPixels;
        uint32_t dataSize = currentPixels * 2;

        // 填充缓冲区
        for (uint32_t j = 0; j < currentPixels; j++) {
            buffer[2 * j] = (image[i + j] >> 8) & 0xFF;
            buffer[2 * j + 1] = image[i + j] & 0xFF;
        }

        // 发送数据
        HAL_SPI_Transmit_DMA(&hspi1, buffer, dataSize);
        // 等待 DMA 传输完成
        while (HAL_SPI_GetState(&hspi1) != HAL_SPI_STATE_READY) {}
    }
}
